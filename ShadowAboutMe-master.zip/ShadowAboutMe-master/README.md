## About Me 

* This website is a static HTML website using semantic tags and minimal CSS. 
* It is currently hosted on Github Pages.
